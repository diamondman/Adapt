org.antlr.runtime.IndexOutOfBoundsException = function(m) {
    org.antlr.runtime.IndexOutOfBoundsException.superclass.constructor.call(this, m);
};

org.antlr.lang.extend(org.antlr.runtime.IndexOutOfBoundsException, Error, {
    name: "org.antlr.runtime.IndexOutOfBoundsException"
});
